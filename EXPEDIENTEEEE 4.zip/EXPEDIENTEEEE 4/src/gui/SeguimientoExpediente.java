/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;

/**
 *
 * @author rodri
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.Expediente;
import tdas.Node;
import java.awt.Color;
import javax.swing.ImageIcon;


public class SeguimientoExpediente extends javax.swing.JFrame {

    /**
     * Creates new form SeguimientoExpediente
     */
    public SeguimientoExpediente(Expediente expediente) {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Seguimiento del Expediente ID: " + expediente.getId());
        // Estilo visual uniforme
getContentPane().setBackground(Color.BLACK);


ImageIcon icono = new ImageIcon(getClass().getResource("/img/logoo.png"));
jLabel1.setIcon(icono);


lblTitulo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 28));
lblTitulo.setForeground(new Color(255, 140, 0)); // Naranja oscuro


btnCerrar.setBackground(new Color(204, 102, 0));
btnCerrar.setForeground(Color.WHITE);
btnCerrar.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
btnCerrar.setFocusPainted(false);


tblSeguimiento.setBackground(new Color(30, 30, 30));
tblSeguimiento.setForeground(Color.WHITE);
tblSeguimiento.setGridColor(Color.DARK_GRAY);
tblSeguimiento.setSelectionBackground(new Color(60, 60, 60));
tblSeguimiento.setSelectionForeground(Color.ORANGE);
tblSeguimiento.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14));
tblSeguimiento.setRowHeight(24);


tblSeguimiento.getTableHeader().setBackground(new Color(80, 80, 80));
tblSeguimiento.getTableHeader().setForeground(Color.WHITE);
tblSeguimiento.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.setColumnIdentifiers(new String[]{"#", "Fecha", "Hora", "Evento"});
        tblSeguimiento.setModel(modelo);

        Node actual = expediente.getSeguimiento().getHead();
        int i = 1;
        while (actual != null) {
            String evento = (String) actual.getValue();
            String[] partes = evento.split(" - ", 3);

            if (partes.length == 3) {
                modelo.addRow(new Object[]{i++, partes[0], partes[1], partes[2]});
            } else {
                modelo.addRow(new Object[]{i++, "", "", evento});
            }

            actual = actual.getNext();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSeguimiento = new javax.swing.JTable();
        btnCerrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Segoe UI Historic", 1, 36)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 102, 204));
        lblTitulo.setText("\"Seguimiento del expediente\"");

        tblSeguimiento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "#Movimientos", "Fecha", "Hora", "Evento"
            }
        ));
        jScrollPane1.setViewportView(tblSeguimiento);

        btnCerrar.setFont(new java.awt.Font("Segoe UI Emoji", 0, 18)); // NOI18N
        btnCerrar.setText("CERRAR");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(323, 323, 323)
                        .addComponent(btnCerrar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(110, 110, 110)
                            .addComponent(lblTitulo))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(331, 331, 331)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(lblTitulo)
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCerrar)
                .addGap(40, 40, 40))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SeguimientoExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SeguimientoExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SeguimientoExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SeguimientoExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTable tblSeguimiento;
    // End of variables declaration//GEN-END:variables
}
