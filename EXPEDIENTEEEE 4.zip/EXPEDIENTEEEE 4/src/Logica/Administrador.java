package logica;

import modelo.Expediente;
import modelo.Dependencia;
import tdas.*;

public class Administrador {

    private String usuario;
    private String contrasena;
    private ABB arbolDependencias;
    private ListaEnlazadaDoble listaExpedientes;
    private Cola colaPendientes;
    private ListaCircularSimple listaAlertas;

    public Administrador(String usuario, String contrasena) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.arbolDependencias = new ABB();
        this.listaExpedientes = new ListaEnlazadaDoble();
        this.colaPendientes = new Cola();
        this.listaAlertas = new ListaCircularSimple();
    }

    public boolean login(String user, String pass) {
        return usuario.equals(user) && contrasena.equals(pass);
    }

    public void registrarExpediente(Expediente exp, int idDependencia) {
        Dependencia dependencia = buscarDependenciaPorId(idDependencia);
        if (dependencia != null) {
            exp.setDependencia(dependencia);
        }

        listaExpedientes.addLast(exp);
        colaPendientes.encolar(exp);
        listaAlertas.addLast(exp);
    }

    public ListaEnlazadaDoble getListaExpedientes() {
        return listaExpedientes;
    }

    public Dependencia buscarDependenciaPorNombre(String nombre) {
        NodoExpediente ptr = listaExpedientes.head;
        while (ptr != null) {
            Dependencia dep = ptr.getExpediente().getDependencia();
            if (dep != null && dep.getNombre().equals(nombre)) {
                return dep;
            }
            ptr = ptr.getNext();
        }
        return null;
    }

    public Dependencia buscarDependenciaPorId(int id) {
        NodoExpediente ptr = listaExpedientes.head;
        while (ptr != null) {
            Dependencia dep = ptr.getExpediente().getDependencia();
            if (dep != null && dep.getId() == id) {
                return dep;
            }
            ptr = ptr.getNext();
        }
        return null;
    }

    public boolean buscarExpediente(int id) {
        return listaExpedientes.buscar(id);
    }

    public Expediente buscarExpedientePorId(int id) {
        return listaExpedientes.buscarPorId(id);
    }

    public ListaCircularSimple getListaAlertas() {
        return listaAlertas;
    }

    public void finalizarTramite(Expediente exp, String fechaFin) {
        exp.setFechaFin(fechaFin);
    }

    public void registrarMovimiento(Expediente exp, String evento) {
        exp.getSeguimiento().addLast(evento);
        String fecha = java.time.LocalDate.now().toString();
        String hora = java.time.LocalTime.now().withNano(0).toString();
        exp.getSeguimiento().addLast(fecha + " - " + hora + " - Enviado a Dirección");

    }

    public void mostrarSeguimiento(Expediente exp) {
        System.out.println("Seguimiento del expediente ID " + exp.getId() + ":");
        exp.getSeguimiento().showElements();
    }

    public void mostrarAlertas() {
        System.out.println("Expedientes pendientes (por orden de llegada y prioridad):");
        NodoExpediente ptr = listaAlertas.head;
        while (ptr != null) {
            System.out.println("ID: " + ptr.getExpediente().getId()
                    + " | Prioridad: " + ptr.getExpediente().getPrioridad());
            ptr = ptr.getNext();
            if (ptr == listaAlertas.head) {
                break;
            }
        }
    }

    public void registrarDependencia(int id, String nombre) {
        Dependencia dep = new Dependencia(id, nombre);
        arbolDependencias.insertar(dep);
    }

    public boolean buscarDependencia(int id) {
        return arbolDependencias.buscar(id);
    }

    public ABB getArbolDependencias() {
        return arbolDependencias;
    }

    public Dependencia buscarDependenciaPorIdEnArbol(int id) {
        return arbolDependencias.buscarPorId(id); // Agrega este método en ABB si no lo tienes
    }

    public ListaEnlazadaDoble getAlertasOrdenadas() {
        ListaEnlazadaDoble ordenadas = new ListaEnlazadaDoble();
        NodoExpediente actual = listaAlertas.head;

        if (actual == null) {
            return ordenadas;
        }

        do {
            Expediente exp = actual.getExpediente();

            if (exp.getFechaFin() == null || exp.getHoraFin() == null) {
                insertarOrdenadoPorPrioridadYTiempo(ordenadas, exp);
            }

            actual = actual.getNext();
        } while (actual != listaAlertas.head);

        return ordenadas;
    }

    private void insertarOrdenadoPorPrioridadYTiempo(ListaEnlazadaDoble lista, Expediente nuevo) {
        NodoExpediente nuevoNodo = new NodoExpediente(nuevo);

        if (lista.head == null) {
            lista.head = lista.tail = nuevoNodo;
            return;
        }

        NodoExpediente actual = lista.head;

        while (actual != null) {
            Expediente expActual = actual.getExpediente();

            boolean esMenor = nuevo.getPrioridad() < expActual.getPrioridad()
                    || (nuevo.getPrioridad() == expActual.getPrioridad()
                    && (nuevo.getFechaInicio().compareTo(expActual.getFechaInicio()) < 0
                    || (nuevo.getFechaInicio().equals(expActual.getFechaInicio())
                    && nuevo.getHoraInicio().compareTo(expActual.getHoraInicio()) < 0)));

            if (esMenor) {
                nuevoNodo.setNext(actual);
                nuevoNodo.setPrev(actual.getPrev());

                if (actual.getPrev() != null) {
                    actual.getPrev().setNext(nuevoNodo);
                } else {
                    lista.head = nuevoNodo;
                }

                actual.setPrev(nuevoNodo);
                return;
            }

            if (actual.getNext() == null) {
                actual.setNext(nuevoNodo);
                nuevoNodo.setPrev(actual);
                lista.tail = nuevoNodo;
                return;
            }

            actual = actual.getNext();
        }
    }

}
