/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package logica;

import javax.swing.Timer;
import gui.VentanaPrincipal;

/** correcion
 * Programamos la aparición periódica de las alertas de expedientes
 * usando el método mostrarAlertas() de VentanaPrincipal.
 */

public class AlertasProgramadas {
    private Timer timer;
    private int intervalo;             // en milisegundos
    private Administrador admin;
    private VentanaPrincipal ventana;

    public AlertasProgramadas(Administrador admin, VentanaPrincipal ventana) {
        this.admin    = admin;
        this.ventana  = ventana;
        this.intervalo = 10000;         // 10 s por defecto
    }

    /** Ajusta el intervalo (ms) de aparición de alertas */
    public void setIntervalo(int ms) {
        this.intervalo = ms;
        if (timer != null) timer.setDelay(ms);
    }

    /** Inicia el timer para disparar ventana.mostrarAlertas() periódicamente */
    public void iniciar() {
        timer = new Timer(intervalo, e -> ventana.mostrarAlertas());
        timer.setRepeats(true);
        timer.start();
    }

    /** Detiene las alertas automáticas */
    public void detener() {
        if (timer != null) timer.stop();
    }
}