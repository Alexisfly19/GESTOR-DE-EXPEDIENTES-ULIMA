package modelo;

import tdas.ListaEnlazada;

public class Expediente {

    private int id;
    private int prioridad;
    private Interesado interesado;
    private String asunto;
    private String documentoReferencia;
    private String fechaInicio;
    private String horaInicio;
    private String fechaFin;
    private String horaFin;
    private Dependencia dependencia;
    private ListaEnlazada seguimiento;
    private String documentoGenerado;

    public Expediente(int id, int prioridad, Interesado interesado, String asunto,
            String documentoReferencia, String fechaInicio, String horaInicio) {
        this.id = id;
        this.prioridad = prioridad;
        this.interesado = interesado;
        this.asunto = asunto;
        this.documentoReferencia = documentoReferencia;
        this.fechaInicio = fechaInicio;
        this.horaInicio = horaInicio;
        this.seguimiento = new ListaEnlazada();
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public Interesado getInteresado() {
        return interesado;
    }

    public String getAsunto() {
        return asunto;
    }

    public String getDocumentoReferencia() {
        return documentoReferencia;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setFechaFin(String f) {
        this.fechaFin = f;
    }

    public void setHoraFin(String h) {
        this.horaFin = h;
    }

    public void setDocumentoGenerado(String doc) {
        this.documentoGenerado = doc;
    }

    public String getDocumentoGenerado() {
        return this.documentoGenerado;
    }

    public Dependencia getDependencia() {
        return dependencia;
    }

    public void setDependencia(Dependencia dependencia) {
        this.dependencia = dependencia;
    }

    public ListaEnlazada getSeguimiento() {
        return seguimiento;
    }
}
