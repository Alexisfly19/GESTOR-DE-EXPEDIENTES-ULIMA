
package tdas;

public class Node {

    private Object value;
    private Node next;
    private Node prev;
    private Node left;
    private Node right;

    public Node(Object value) {
        this.value = value;
        this.next = null;
        this.prev = null;
        this.left = null;
        this.right = null;
    }

    public Object getValue() {
        return value;
    }

    public Node getNext() {
        return next;
    }

    public Node getPrev() {
        return prev;
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }

    public void setNext(Node next) {
        this.next = next;
    }

    public void setPrev(Node prev) {
        this.prev = prev;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public void setRight(Node right) {
        this.right = right;
    }
}
