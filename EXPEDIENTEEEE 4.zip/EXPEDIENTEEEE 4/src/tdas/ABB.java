package tdas;

import modelo.Dependencia;
import tdas.ListaEnlazada;

public class ABB {

    private Node root;

    public ABB() {
        this.root = null;
    }

    public void insertar(Dependencia dep) {
        root = insertarRec(root, dep);
    }

    private Node insertarRec(Node root, Dependencia dep) {
        if (root == null) {
            return new Node(dep);
        }
        Dependencia actual = (Dependencia) root.getValue();
        if (dep.getId() < actual.getId()) {
            root.setLeft(insertarRec(root.getLeft(), dep));
        } else {
            root.setRight(insertarRec(root.getRight(), dep));
        }
        return root;
    }

    public boolean buscar(int id) {
        return buscarRec(root, id);
    }

    private boolean buscarRec(Node root, int id) {
        if (root == null) {
            return false;
        }
        Dependencia actual = (Dependencia) root.getValue();
        if (actual.getId() == id) {
            return true;
        }
        if (id < actual.getId()) {
            return buscarRec(root.getLeft(), id);
        } else {
            return buscarRec(root.getRight(), id);
        }
    }

    public void inOrdenCombo(javax.swing.JComboBox<String> combo) {
        inOrdenComboRec(root, combo);
    }

    private void inOrdenComboRec(Node root, javax.swing.JComboBox<String> combo) {
        if (root != null) {
            inOrdenComboRec(root.getLeft(), combo);
            Dependencia dep = (Dependencia) root.getValue();
            combo.addItem(dep.getId() + " - " + dep.getNombre());
            inOrdenComboRec(root.getRight(), combo);
        }
    }

    public Dependencia buscarPorId(int id) {
        return buscarNodoPorId(root, id);
    }

    private Dependencia buscarNodoPorId(Node root, int id) {
        if (root == null) {
            return null;
        }

        Dependencia dep = (Dependencia) root.getValue();

        if (dep.getId() == id) {
            return dep;
        }
        if (id < dep.getId()) {
            return buscarNodoPorId(root.getLeft(), id);
        } else {
            return buscarNodoPorId(root.getRight(), id);
        }
    }

    public ListaEnlazada inOrdenLista() {
        ListaEnlazada lista = new ListaEnlazada();
        inOrdenListaRec(root, lista);
        return lista;
    }

    private void inOrdenListaRec(Node nodo, ListaEnlazada lista) {
        if (nodo != null) {
            inOrdenListaRec(nodo.getLeft(), lista);
            lista.addLast(nodo.getValue()); // Agrega el objeto Dependencia
            inOrdenListaRec(nodo.getRight(), lista);
        }
    }

    public void llenarCombo(javax.swing.JComboBox<Dependencia> combo) {
        llenarComboRec(root, combo);
    }

    private void llenarComboRec(Node nodo, javax.swing.JComboBox<Dependencia> combo) {
        if (nodo != null) {
            llenarComboRec(nodo.getLeft(), combo);
            combo.addItem((Dependencia) nodo.getValue());
            llenarComboRec(nodo.getRight(), combo);
        }
    }

}
